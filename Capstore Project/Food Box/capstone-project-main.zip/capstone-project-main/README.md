# capstone-project
This Repository conatins both Angular JS and Spring Boot code
